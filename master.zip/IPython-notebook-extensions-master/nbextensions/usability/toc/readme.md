Table of content of the notebooks markdown headers


Description
===========

The extension installs a new button which opens a table of content for 
the headlines defined in this notebook. Currently only the first four 
levels (h1-h4 or up to '####' headlines in markdown) are displayed.

Due to [restrictions in the current notebook format](https://github.com/jupyter/notebook/issues/77), 
recurrent headlines cannot be distinguished and the ToC will link to the 
first occurrence. 

