**************************************************************************
**IPython-contrib-nbextensions - (C) 2013-2016, IPython-contrib Developers - 
All rights reserved.**

The IPython-contrib-nbextensions is a permanently updated collection 
of extensions that add functionality to the Jupyter notebook. 
These extensions are mostly written in Javascript and will be loaded 
locally in your Browser. The present program downloads and installs 
the current master of the collection at
https://github.com/ipython-contrib/IPython-notebook-extensions

Installation of the distribution to the current user directories, 
configuration files and paths is done by 
> Jupyter_nb_contribs.py install

**Caution**: for now, the installation overwrites existing files..

The IPython-contrib repository 
[https://github.com/ipython-contrib/IPython-notebook-extensions](https://github.com/ipython-contrib/IPython-notebook-extensions) 
is maintained independently by a group of users and developers and 
not officially related to the IPython development team.

The maturity of the provided extensions may vary, please create 
an issue if you encounter any problems.

Once the extensions are installed, you will be able to look at 
the description of each extension, activate some and play with them 
using the nbextensions server extension by opening a brower tab at 
localhost:8888/nbextensions. 

![Extensions](https://raw.githubusercontent.com/ipython-contrib/IPython-notebook-extensions/master/nbextensions/config/icon.png)

Enjoy!

Released under Modified BSD License, read COPYING file for more details.



